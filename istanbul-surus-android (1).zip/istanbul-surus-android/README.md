# İstanbul Sürüş — Play Store paketi (Capacitor / Android)

Bu klasör, oyunu (www/index.html) Android uygulamasına çevirip Play Store'a yüklemek için hazırlandı.
**Bunu burada derleyemedim; derleme ve yükleme senin bilgisayarında yapılır.** Adımlar test edilmedi,
Capacitor/Android Studio sürümlerine göre küçük farklar çıkabilir.

## 1. Gerekenler
- Node.js (LTS), Android Studio (güncel sürüm; SDK Platform **36** kurulu olsun)
- Google Play geliştirici hesabı (aşağıda "Hesap" bölümü)

## 2. Kurulum
```
npm install
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli @capacitor/assets
npx cap add android
```
`npm install` three.js'i `www/three.min.js` olarak kopyalar, böylece uygulama internetsiz çalışır.

**Paket adı:** `capacitor.config.json` içindeki `appId` (`com.istanbulsurus.oyun`) Play'de **bir kez**
seçilir ve sonra değiştirilemez. Başka bir ad istiyorsan `npx cap add android` yapmadan önce değiştir
(ve `android-patch/MainActivity.java` içindeki `package` satırını da buna göre değiştir).
`com.example` ile başlayan adlar Play'e yüklenmez.

## 3. Android ayarları
1. **Hedef API:** `android/variables.gradle` içinde `compileSdkVersion` ve `targetSdkVersion` değerleri **36 veya üstü**
   olmalı. Google, 31 Ağustos 2026'dan itibaren yeni uygulamaların Android 16'yı (API 36) hedeflemesini şart koşuyor.
   Capacitor sürümün zaten 36 veriyorsa dokunma.
2. **Yatay ekran:** `android/app/src/main/AndroidManifest.xml` içinde `<activity ...>` etiketine
   `android:screenOrientation="sensorLandscape"` ekle.
3. **Tam ekran ve ekran açık kalsın (isteğe bağlı):** `android-patch/MainActivity.java` dosyasını
   `android/app/src/main/java/com/istanbulsurus/oyun/MainActivity.java` üzerine kopyala.
4. **İkonlar:** `npx capacitor-assets generate --android` (assets/ klasöründeki görselleri kullanır).

## 4. Derle ve cihazda dene
```
npx cap sync android
npx cap open android
```
Android Studio'da tabletini bağlayıp Run'a bas. **Yayınlamadan önce en az bir gerçek cihazda** şunları dene:
ses, dokunmatik tuşlar, uygulamayı arka plana alıp geri dönme, uzun süre oynarken akıcılık.

## 5. İmzalı paket (AAB)
Android Studio: **Build > Generate Signed App Bundle > Android App Bundle**. İlk seferde bir keystore oluştur.
**Keystore dosyasını ve şifresini yedekle**; kaybedersen uygulamayı güncelleyemezsin. Play, `.aab` ister (`.apk` değil).

## 6. Play Console
- **Hesap:** Kayıt ücreti vardır (miktarını doğrulamadım, kayıt sırasında görürsün).
  Kişisel hesap 13 Kasım 2023'ten sonra açıldıysa, üretime çıkmadan önce **en az 12 test kullanıcısıyla,
  14 gün kesintisiz kapalı test** yapman gerekir (Google'ın yardım sayfasında böyle). Kuruluş hesabı bundan muaf.
  Süreci 3 hafta civarı hesaba kat.
- **Mağaza girişi:** `play-store/store-listing.md` (başlık, kısa ve uzun açıklama), `play-store-icon-512.png`,
  `feature-graphic-1024x500.png`. **En az 2 ekran görüntüsünü** oyundan kendin almalısın.
- **Gizlilik politikası:** `play-store/privacy-policy.md` metnini bir web sayfasında (ör. GitHub Pages) yayınla,
  adresini Play Console'a gir.
- **Veri güvenliği formu:** Oyun kişisel veri toplamıyor ve paylaşmıyor (ayarlar yalnızca cihazda saklanır).
  Reklam, hesap, analitik yok. Sonradan bunlardan birini eklersen formu ve politikayı güncelle.
- **İçerik derecelendirme anketi:** Dürüst doldur. Oyunda araç çarpışması ve **yayaya çarpma** var
  (kan yok, ama çarpılan yaya yere düşüyor). Anketin sonucu yaş derecesini belirler.
- **Telif:** Gerçek araba markası/logosu yok, ses kodla üretiliyor, şehir ve yapılar genel. Sonradan
  lisanssız müzik, marka veya model eklersen sorun çıkar.

## 7. GitHub'a yükleme
1. github.com'da boş bir depo oluştur (README, .gitignore veya lisans ekleme).
2. Bu klasörde:
```
git init
git add .
git commit -m "İstanbul Sürüş: ilk sürüm"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/istanbul-surus.git
git push -u origin main
```
(GitHub CLI kuruluysa tek satır: `gh repo create istanbul-surus --private --source=. --push`)

- `.gitignore` imzalama anahtarını (`*.jks`, `*.keystore`) ve şifre dosyalarını dışarıda tutar. Anahtarı
  **hiçbir zaman** depoya koyma, ayrı bir yere yedekle.
- `www/three.min.js` depoya girmez; `npm install` onu yeniden oluşturur.
- Gizlilik politikası adresi için: depoyu public yap, Settings > Pages > Branch `main`, klasör `/docs`
  seç. `docs/privacy-policy.md` bir adreste yayınlanır; o adresi Play Console'a gir.
  (Depoyu private tutacaksan politikayı başka bir yerde yayınlaman gerekir.)
- `npx cap add android` sonrası oluşan `android/` klasörünü de depoya ekle (Capacitor bunu önerir).
