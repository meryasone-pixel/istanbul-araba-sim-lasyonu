# Gizlilik Politikası — İstanbul Sürüş

Son güncelleme: (tarihi yaz)

**Toplanan veri:** İstanbul Sürüş, kişisel veri toplamaz, saklamaz veya üçüncü taraflarla paylaşmaz.
Hesap, konum, kamera, mikrofon, rehber veya depolama izni istemez.

**Cihazda saklanan bilgiler:** Düğme boyutu ve grafik kalitesi gibi oyun ayarları yalnızca senin cihazında
saklanır ve uygulamayı kaldırdığında silinir.

**İnternet:** Oyun internet bağlantısı olmadan çalışır; uygulama ağ isteği göndermez.

**Reklam ve analitik:** Uygulamada reklam veya analitik hizmeti yoktur.

**İletişim:** (e-posta adresini yaz)

---

# Privacy Policy — İstanbul Sürüş (English)

Last updated: (add date)

İstanbul Sürüş does not collect, store, or share personal data. It does not request account, location,
camera, microphone, contacts, or storage permissions. Game settings (such as button size and graphics
quality) are stored only on your device and are removed when you uninstall the app. The game works offline
and does not send network requests. There are no ads or analytics.

Contact: (add email address)
