# Mağaza girişi (Türkçe)

**Başlık (en fazla 30 karakter):**
İstanbul Sürüş

**Kısa açıklama (en fazla 80 karakter):**
İstanbul’da akşam sürüşü: trafik, ışıklar, yayalar, gece ve gündüz modu.

**Uzun açıklama:**
İstanbul sokaklarında kendi arabanla özgürce sür.

• Trafikte seninle birlikte onlarca araç ve kaldırımlarda yürüyen insanlar var
• Ana caddedeki trafik ışıklarına uy, kırmızıda geçme
• Çarpışmalar gerçek sonuçlar doğurur: araban hasar görür, parçalar kopar, duman çıkar
• Gündüz, akşam ve gece modu; far aç/kapa
• Arabanın rengini seç
• Arkadan, kokpitten ve yukarıdan kamera
• Galata Kulesi ve Sultanahmet’ten esinlenen yapılar, köprü ve Boğaz
• Dokunmatik ekran için ayarlanabilir düğmeler
• İnternet gerekmez, reklam yok

Sürüş puanın trafik kurallarına ve dikkatine göre düşer. 100 puanla başla, kazasız sür.

Not: Bu oyun bir eğlence simülasyonudur; gerçek trafik kurallarının yerine geçmez.
